import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// FIX 5: Kein blindes Vertrauen — wenn #root fehlt, klare Fehlermeldung
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Fehler: Das Element #root wurde im HTML nicht gefunden. Bitte index.html prüfen.");
}
createRoot(rootElement).render(<App />);
